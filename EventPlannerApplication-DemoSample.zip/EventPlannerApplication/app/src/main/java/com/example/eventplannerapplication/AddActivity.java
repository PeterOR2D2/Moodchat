package com.example.eventplannerapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;
import android.app.DatePickerDialog;
import android.widget.DatePicker;
import android.graphics.Color;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity {

    private DatabaseReference myRef;
    private FirebaseDatabase database;
    private TextView eventDate;
    private EditText editEventName;
    private EditText editEventDescription;
    private DatePickerDialog datePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        this.database = FirebaseDatabase.getInstance();
        this.myRef = database.getReference().child("Events");

        editEventName = findViewById(R.id.editEventTextName);
        editEventName.setTextColor(Color.parseColor("#FFFF00"));

        editEventDescription = findViewById(R.id.editEventTextDescription);
        editEventDescription.setTextColor(Color.parseColor("#FFFF00"));

        eventDate = (TextView) findViewById(R.id.editEventDate);
        eventDate.setTextColor(Color.parseColor("#FFFF00"));
        eventDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar cdar = Calendar.getInstance();
                int emonth = cdar.get(Calendar.MONTH);
                int eday = cdar.get(Calendar.DAY_OF_MONTH);
                int eyear = cdar.get(Calendar.YEAR);
                datePickerDialog = new DatePickerDialog(AddActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        eventDate.setText((month+1) + "/" + dayOfMonth + "/" + year);
                    }
                }, eyear, emonth, eday);
                datePickerDialog.show();
            }
        });
    }

    public void addEvent(View view)
    {

        String EventName = editEventName.getText().toString();
        String EventDescription = editEventDescription.getText().toString();
        //EditText editEventDate = findViewById(R.id.editEventDate);
        String EventDate = this.eventDate.getText().toString();
        System.out.println(EventDate+" "+EventName+" "+EventDescription);

        if((EventName.length() > 0) && (EventDate.length() > 0))
        {
            String uid_key = myRef.push().getKey();
            System.out.println(uid_key);
            EventPlanner eplan = new EventPlanner(EventName, EventDescription, EventDate, uid_key);
            myRef.child(uid_key).setValue(eplan);
            Toast.makeText(this, eplan.getEventName() + " has been created.", Toast.LENGTH_LONG).show();
        }

    }

    public void HomeEvent(View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

}
