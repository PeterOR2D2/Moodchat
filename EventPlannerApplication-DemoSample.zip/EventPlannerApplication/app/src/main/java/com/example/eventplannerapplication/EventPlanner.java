package com.example.eventplannerapplication;

public class EventPlanner {
    private String eventName;
    private String eventDescription;
    private String eventDate;
    private String uid;

    public EventPlanner()
    {
        this.eventName = "NA";
        this.eventDescription = "NA";
        this.eventDate = "NA";
    }

    public EventPlanner(String ename, String edescription, String edate, String euid)
    {
        this.eventName = ename;
        this.eventDescription = edescription;
        this.eventDate = edate;
        this.uid = euid;
    }

    public String getEventName() { return this.eventName; }

    public String getEventDescription() { return this.eventDescription; }

    public String getEventDate() { return this.eventDate; }

    public String getEUID() { return this.uid; }

    public String toString() { return this.eventName + "\n" + this.eventDescription + "\n" + this.eventDate; }

}
