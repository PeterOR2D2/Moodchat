package com.example.eventplannerapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import android.os.Bundle;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private FirebaseDatabase database;
    private DatabaseReference myRef;

    private ChildEventListener childEventListener;

    private ArrayList<EventPlanner> eventplannerList;
    private ArrayList<EventPlanner> Resultsearch;

    private EventPlannerAdapter Adapterlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        this.database = FirebaseDatabase.getInstance();
        this.myRef = database.getReference().child("Events");

        this.eventplannerList = new ArrayList<EventPlanner>();
        this.Resultsearch = new ArrayList<EventPlanner>();

        this.childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                eventplannerList.add(dataSnapshot.getValue(EventPlanner.class));
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        };

        this.myRef.addChildEventListener(this.childEventListener);

        this.Adapterlist = new EventPlannerAdapter(this,this.Resultsearch);
        ListView result = findViewById(R.id.resultListView);
        result.setAdapter(this.Adapterlist);
    }

    public void searchDate(View view)
    {
        this.Adapterlist.clear();
        boolean found = false;

        for(EventPlanner ePlanner: this.eventplannerList)
        {
            EditText textdate = (EditText) findViewById(R.id.editTextDate);
            String search_result = textdate.getText().toString();
            if(ePlanner.getEventDate().equals(search_result))
            {
                this.Adapterlist.add(ePlanner);
                found = true;
            }
        }
        EditText search_result = (EditText) findViewById(R.id.editTextDate);
        if(!(found))
        {
            Toast.makeText(this, search_result.getText().toString() + " has not been found.", Toast.LENGTH_LONG).show();
        }
        search_result.setText("");
    }

    public void HomeEvent(View view)
    {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
